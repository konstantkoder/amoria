import React, { useMemo, useState } from "react";
import { Modal, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";

import { type BackgroundKey } from "@/assets/backgrounds";
import BackgroundWrapper from "@/components/BackgroundWrapper";

type MenuItem = {
  label: string;
  route: string;
};

type Props = {
  title?: string;
  background: BackgroundKey;
  showBack?: boolean;
  onBack?: () => void;
  children: React.ReactNode;
};

export default function ScreenShell({
  title,
  background,
  showBack,
  onBack,
  children,
}: Props) {
  const navigation = useNavigation<any>();
  const [menuOpen, setMenuOpen] = useState(false);

  const menuItems: MenuItem[] = useMemo(
    () => [{ label: "Профиль", route: "Profile" }],
    []
  );

  const handleBack = () => {
    if (onBack) {
      onBack();
      return;
    }
    if (navigation.canGoBack()) {
      navigation.goBack();
    }
  };

  const handleNavigate = (route: string) => {
    setMenuOpen(false);
    navigation.navigate(route as never);
  };

  return (
    <BackgroundWrapper background={background}>
      <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
        <View style={styles.header}>
          <View style={styles.headerSide}>
            {showBack ? (
              <TouchableOpacity
                onPress={handleBack}
                style={styles.iconButton}
                activeOpacity={0.85}
              >
                <Ionicons name="chevron-back" size={22} color="#fff" />
              </TouchableOpacity>
            ) : null}
          </View>

          <View style={styles.titleWrap}>
            {title ? (
              <Text style={styles.title} numberOfLines={1}>
                {title}
              </Text>
            ) : null}
          </View>

          <View style={styles.headerSide}>
            <TouchableOpacity
              onPress={() => setMenuOpen(true)}
              style={styles.iconButton}
              activeOpacity={0.85}
            >
              <Ionicons name="menu-outline" size={22} color="#fff" />
              <Text style={styles.menuLabel}>Меню</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>

      <SafeAreaView style={styles.bodySafe} edges={["left", "right", "bottom"]}>
        <View style={styles.content}>{children}</View>
      </SafeAreaView>

      <Modal
        visible={menuOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setMenuOpen(false)}
      >
        <TouchableOpacity
          activeOpacity={1}
          style={styles.modalBackdrop}
          onPress={() => setMenuOpen(false)}
        >
          <View style={styles.menuCard}>
            {menuItems.map((item) => (
              <TouchableOpacity
                key={item.route}
                onPress={() => handleNavigate(item.route)}
                style={styles.menuItem}
                activeOpacity={0.9}
              >
                <Text style={styles.menuItemText}>{item.label}</Text>
                <Ionicons
                  name="chevron-forward"
                  size={16}
                  color="rgba(255,255,255,0.7)"
                />
              </TouchableOpacity>
            ))}
            <TouchableOpacity
              onPress={() => setMenuOpen(false)}
              style={[styles.menuItem, styles.menuClose]}
              activeOpacity={0.85}
            >
              <Text style={styles.menuCloseText}>Закрыть</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>
    </BackgroundWrapper>
  );
}

const styles = StyleSheet.create({
  safe: { paddingHorizontal: 12 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
  },
  headerSide: { width: 90, flexDirection: "row", alignItems: "center" },
  titleWrap: { flex: 1, alignItems: "center" },
  title: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "800",
    letterSpacing: 0.4,
  },
  iconButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: "rgba(0,0,0,0.25)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
  },
  menuLabel: { color: "#fff", fontSize: 12, fontWeight: "700" },
  bodySafe: { flex: 1, paddingHorizontal: 12 },
  content: { flex: 1 },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.55)",
    justifyContent: "flex-end",
    padding: 18,
  },
  menuCard: {
    backgroundColor: "rgba(15,15,25,0.95)",
    borderRadius: 18,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.12)",
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.05)",
  },
  menuItemText: {
    color: "#fff",
    fontSize: 15,
    fontWeight: "700",
  },
  menuClose: { borderBottomWidth: 0 },
  menuCloseText: {
    color: "rgba(255,255,255,0.7)",
    fontSize: 14,
    fontWeight: "700",
  },
});
