import { UserProfile } from "../models/User";

export type DemoUser = Partial<UserProfile> & {
  age?: number;
  distanceKm?: number;
  bio?: string;
  name?: string;
};

export const DEMO_USERS: DemoUser[] = [
  {
    uid: "demo_anna",
    displayName: "Анна, 28",
    about: "Маркетолог, люблю кофе и длинные прогулки.",
    interests: ["кофе", "прогулки", "кино", "йога"],
    photos: [],
    mood: "happy",
    goal: "dating",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    geo: { lat: 45.812, lng: 15.975, geohash: "u2yh…" },
    hasVoiceIntro: true,
    voiceIntroDurationSec: 7,
  },
  {
    uid: "demo_maria",
    displayName: "Мария, 31",
    about: "Интроверт, книги, сериалы и уютные барахолки.",
    interests: ["книги", "сериалы", "котики", "арт"],
    photos: [],
    mood: "chill",
    goal: "friends",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    geo: { lat: 45.817, lng: 15.985, geohash: "u2yh…" },
    hasVoiceIntro: true,
    voiceIntroDurationSec: 9,
  },
  {
    uid: "demo_olga",
    displayName: "Ольга, 26",
    about: "Обожаю путешествия автостопом и фотографировать города.",
    interests: ["фото", "поездки", "кофейни"],
    photos: [],
    mood: "active",
    goal: "chat",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    geo: { lat: 45.81, lng: 15.99, geohash: "u2yh…" },
  },
  {
    uid: "demo_irina",
    displayName: "Ирина, 29",
    about: "Ищу собеседников для настолок и фильмов.",
    interests: ["настолки", "сцifi", "марвел"],
    photos: [],
    mood: "serious",
    goal: "long_term",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    geo: { lat: 45.819, lng: 15.97, geohash: "u2yh…" },
  },
  {
    uid: "demo_vika",
    displayName: "Вика, 25",
    about: "Тусовки, концерты и спонтанные поездки на море.",
    interests: ["концерты", "поп", "пляж"],
    photos: [],
    mood: "party",
    goal: "short_term",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    geo: { lat: 45.813, lng: 15.98, geohash: "u2yh…" },
  },
  {
    uid: "demo_liza",
    displayName: "Лиза, 27",
    about: "Люблю готовить пасту и смотреть стендап.",
    interests: ["еда", "стендап", "путешествия"],
    photos: [],
    mood: "happy",
    goal: "casual",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    geo: { lat: 45.816, lng: 15.982, geohash: "u2yh…" },
    hasVoiceIntro: true,
    voiceIntroDurationSec: 12,
  },
];
