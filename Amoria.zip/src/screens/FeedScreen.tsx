import React, { useEffect, useMemo, useState } from "react";
import { ScrollView, View, Text, Alert, TouchableOpacity } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

import UserCard from "@/components/UserCard";
import { DEMO_USERS, type DemoUser } from "@/services/demoUsers";
import { QUESTIONS, getDailyQuestionId } from "@/services/questions";
import { loadAdultModeEnabled } from "@/services/adultMode";
import { theme } from "@/theme";
import VoiceIntroModal from "@/components/VoiceIntroModal";
import ScreenShell from "@/components/ScreenShell";
import { addDislike, addLike, getLikes } from "@/services/likes";

export default function FeedScreen() {
  const [adultModeEnabled, setAdultModeEnabled] = useState(false);
  const [voiceIntroUser, setVoiceIntroUser] = useState<DemoUser | null>(null);
  const [likedIds, setLikedIds] = useState<string[]>([]);
  const questionText = useMemo(() => {
    const qid = getDailyQuestionId();
    const q = QUESTIONS.find((item) => item.id === qid);
    return q?.text ?? "Сегодняшний вопрос недоступен.";
  }, []);

  const previewUsers = useMemo(() => {
    return DEMO_USERS.slice(0, 5);
  }, []);

  const insets = useSafeAreaInsets();
  useEffect(() => {
    let isMounted = true;
    (async () => {
      const enabled = await loadAdultModeEnabled();
      if (isMounted) {
        setAdultModeEnabled(enabled);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const ids = await getLikes();
        if (alive) {
          setLikedIds(ids);
        }
      } catch {
        // ignore
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const handleOpenUser = (user: DemoUser) => {
    const subtitle =
      user.bio ??
      user.about ??
      "В полной версии здесь откроется подробный профиль и чат.";
    const title = user.displayName ?? user.name ?? "Профиль";
    const ageSuffix = user.age ? `, ${user.age}` : "";

    Alert.alert(
      `${title}${ageSuffix}`,
      `${subtitle}\n\nСейчас это демо-профиль. В релизе здесь будет экран анкеты и чат.`,
      [{ text: "OK" }]
    );
  };

  const handleOpenVoiceIntro = (user: DemoUser) => {
    setVoiceIntroUser(user);
  };

  const handleCloseVoiceIntro = () => {
    setVoiceIntroUser(null);
  };

  const onLike = async (user: DemoUser) => {
    if (!user.uid) return;
    const next = await addLike(user.uid);
    setLikedIds(next);
    Alert.alert(
      "Лайк ✅",
      `${user.displayName ?? user.name ?? "Пользователь"} добавлен(а) в лайкнутые.\nПозже здесь будет переход в чат/матч.`
    );
  };

  const onDislike = async (user: DemoUser) => {
    if (!user.uid) return;
    await addDislike(user.uid);
  };

  const isLiked = (user: DemoUser) => {
    if (!user.uid) return false;
    return likedIds.includes(user.uid);
  };

  return (
    <ScreenShell title="AMORIA" background="hearts">
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 16,
          paddingBottom: 32 + insets.bottom,
        }}
      >
        {/* Карточка "Вопрос дня" */}
        <View
          style={{
            backgroundColor: theme.colors.card,
            borderRadius: 24,
            padding: 16,
            marginBottom: 24,
          }}
        >
          <Text
            style={{
              color: theme.colors.muted,
              fontSize: 14,
              marginBottom: 8,
            }}
          >
            Вопрос дня
          </Text>
          <Text
            style={{
              color: theme.colors.text,
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 8,
            }}
          >
            {questionText}
          </Text>
          <Text
            style={{
              color: theme.colors.muted,
              fontSize: 13,
            }}
          >
            Ответ можно написать во вкладке «Question» внизу экрана.
          </Text>
        </View>

        {/* Блок "Рядом с тобой" */}
        <Text
          style={{
            color: theme.colors.text,
            fontSize: 18,
            fontWeight: "600",
            marginBottom: 12,
          }}
        >
          Рядом с тобой
        </Text>

        {!adultModeEnabled && (
          <Text
            style={{
              color: "#A1A1AA",
              fontSize: 12,
              marginBottom: 8,
            }}
          >
            18+ цели (casual/sex) сейчас скрыты. Ты можешь включить 18+ режим
            во вкладке «Profile», чтобы видеть больше анкет.
          </Text>
        )}

        {previewUsers.length === 0 && (
          <Text
            style={{
              color: theme.colors.muted,
              fontSize: 14,
            }}
          >
            Поблизости пока никого. Попробуй позже.
          </Text>
        )}

        {previewUsers.map((user) => (
          <View key={user.uid} style={{ marginBottom: 18 }}>
            <View style={{ height: 320 }}>
              <UserCard
                user={user}
                onPress={handleOpenUser}
                onPressVoiceIntro={handleOpenVoiceIntro}
              />
            </View>

            <View
              style={{
                flexDirection: "row",
                gap: 10,
                marginTop: 10,
              }}
            >
              <TouchableOpacity
                activeOpacity={0.9}
                onPress={() => onDislike(user)}
                style={{
                  flex: 1,
                  height: 46,
                  borderRadius: 16,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: "rgba(148, 163, 184, 0.14)",
                  borderWidth: 1,
                  borderColor: "rgba(255,255,255,0.08)",
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <Ionicons name="close" size={18} color={theme.colors.text} />
                  <Text
                    style={{
                      marginLeft: 8,
                      color: theme.colors.text,
                      fontWeight: "700",
                    }}
                  >
                    Не моё
                  </Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                activeOpacity={0.9}
                onPress={() => onLike(user)}
                style={{
                  flex: 1,
                  height: 46,
                  borderRadius: 16,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: isLiked(user)
                    ? "rgba(34, 197, 94, 0.22)"
                    : "rgba(236, 72, 153, 0.22)",
                  borderWidth: 1,
                  borderColor: "rgba(255,255,255,0.10)",
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <Ionicons name="heart" size={18} color={theme.colors.text} />
                  <Text
                    style={{
                      marginLeft: 8,
                      color: theme.colors.text,
                      fontWeight: "800",
                    }}
                  >
                    {isLiked(user) ? "Лайкнуто" : "Лайк"}
                  </Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
      <VoiceIntroModal
        visible={!!voiceIntroUser}
        onClose={handleCloseVoiceIntro}
        userName={voiceIntroUser?.displayName ?? voiceIntroUser?.name}
        durationSeconds={voiceIntroUser?.voiceIntroDurationSec ?? 8}
      />
    </ScreenShell>
  );
}
