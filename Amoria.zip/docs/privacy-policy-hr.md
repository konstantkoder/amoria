# Pravila privatnosti — Amoria
Ažurirano: 15.08.2025.

**Podaci koje prikupljamo**
- Profil (ime, datum rođenja, spol, interesi, cilj, raspoloženje)
- Lokacija tijekom korištenja aplikacije
- Korisnički sadržaj (poruke, prijave, blokiranja)

**Svrha**
- Funkcija "ljudi u blizini" i sparivanje prema interesima.

**Dijeljenje**
- Ne prodajemo podatke. Dijelimo samo s pružateljima usluga (npr. Firebase), prema potrebi.

**Zadržavanje i brisanje**
- Do brisanja računa od strane korisnika (u aplikaciji).

**Kontakt**
- support@amoria.app
