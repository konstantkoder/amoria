# Privacy Policy — Amoria
Updated: 2025-08-15

**Data we collect**
- Profile (name, birthdate, gender, interests, goal, mood)
- Location while the app is in use
- User content (messages, reports, blocks)

**Purpose**
- People-nearby feature and interest-based matching.

**Sharing**
- No selling. Service providers (e.g., Firebase) only, as needed.

**Retention & Deletion**
- Until the account is deleted by the user (in-app).

**Contact**
- support@amoria.app
